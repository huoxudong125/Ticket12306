﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Security;  
using System.Security.Authentication;  
using System.Security.Cryptography.X509Certificates;
using System.Net;
using System.Drawing;
using System.IO;
namespace FuckCaptcha
{
    static class Service_DownLoadImage
    {
        public static Bitmap Get_Image()
        {
            try
            {
                string URL = "https://dynamic.12306.cn/otsweb/passCodeAction.do?rand=lrand";
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(CheckValidationResult);//验证服务器证书回调自动验证
                WebRequest request = WebRequest.Create(URL);
                request.Timeout = 3000;

                WebResponse response = request.GetResponse();
                Stream responseStream = response.GetResponseStream();
                Bitmap img = new Bitmap(responseStream);
                responseStream.Close();
                response.Close();
                return img;
            }
            catch (WebException e)
            {
                using (WebResponse response = e.Response)
                {
                    if (response != null)
                    {
                        HttpWebResponse httpResponse = (HttpWebResponse)response;
                        switch (httpResponse.StatusCode)
                        {
                            case HttpStatusCode.RequestTimeout: break;
                            default: break;
                        }
                    }
                }
                return null;
            }
        }
        private static bool CheckValidationResult(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
        {   // 总是接受    
            return true;
        } 
    }
}
