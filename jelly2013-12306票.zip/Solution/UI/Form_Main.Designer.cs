﻿namespace Jelly2013
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Main));
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lstMsg = new System.Windows.Forms.ListBox();
            this.picValidImg = new System.Windows.Forms.PictureBox();
            this.picLoginIE = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtVerificationCode = new System.Windows.Forms.TextBox();
            this.gobLoginInfo = new System.Windows.Forms.GroupBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.gobSearch = new System.Windows.Forms.GroupBox();
            this.pnlTrainType = new System.Windows.Forms.Panel();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cboStartTime = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.cboToStation = new System.Windows.Forms.ComboBox();
            this.dateStartDate = new System.Windows.Forms.DateTimePicker();
            this.cboFromStation = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvTiketInfo = new System.Windows.Forms.DataGridView();
            this.gobRefresh = new System.Windows.Forms.GroupBox();
            this.lblSeate = new System.Windows.Forms.Label();
            this.gobPassenger = new System.Windows.Forms.GroupBox();
            this.chbListPassenger = new System.Windows.Forms.CheckedListBox();
            this.gobSeatType = new System.Windows.Forms.GroupBox();
            this.chbListSeatType = new System.Windows.Forms.CheckedListBox();
            this.label12 = new System.Windows.Forms.Label();
            this.numJiange = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.chbMusic = new System.Windows.Forms.CheckBox();
            this.chbAutoOrder = new System.Windows.Forms.CheckBox();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.gobSelectedTicket = new System.Windows.Forms.GroupBox();
            this.lsbSelectedTicket = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picValidImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLoginIE)).BeginInit();
            this.gobLoginInfo.SuspendLayout();
            this.gobSearch.SuspendLayout();
            this.pnlTrainType.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTiketInfo)).BeginInit();
            this.gobRefresh.SuspendLayout();
            this.gobPassenger.SuspendLayout();
            this.gobSeatType.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numJiange)).BeginInit();
            this.gobSelectedTicket.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstMsg
            // 
            this.lstMsg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lstMsg.FormattingEnabled = true;
            this.lstMsg.HorizontalScrollbar = true;
            this.lstMsg.ItemHeight = 12;
            this.lstMsg.Location = new System.Drawing.Point(798, 137);
            this.lstMsg.Name = "lstMsg";
            this.lstMsg.Size = new System.Drawing.Size(209, 196);
            this.lstMsg.TabIndex = 3;
            this.toolTip1.SetToolTip(this.lstMsg, "执行结果");
            // 
            // picValidImg
            // 
            this.picValidImg.Location = new System.Drawing.Point(494, 24);
            this.picValidImg.Name = "picValidImg";
            this.picValidImg.Size = new System.Drawing.Size(78, 26);
            this.picValidImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picValidImg.TabIndex = 38;
            this.picValidImg.TabStop = false;
            this.toolTip1.SetToolTip(this.picValidImg, "看不清?点击更换一个验证码");
            this.picValidImg.Click += new System.EventHandler(this.picValidImg_Click);
            // 
            // picLoginIE
            // 
            this.picLoginIE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picLoginIE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picLoginIE.Image = global::Jelly2013.Properties.Resources.ie;
            this.picLoginIE.Location = new System.Drawing.Point(890, 29);
            this.picLoginIE.Margin = new System.Windows.Forms.Padding(2);
            this.picLoginIE.Name = "picLoginIE";
            this.picLoginIE.Size = new System.Drawing.Size(48, 48);
            this.picLoginIE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picLoginIE.TabIndex = 48;
            this.picLoginIE.TabStop = false;
            this.toolTip1.SetToolTip(this.picLoginIE, "在IE浏览器中打开12306网站");
            this.picLoginIE.Visible = false;
            this.picLoginIE.Click += new System.EventHandler(this.picLoginIE_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 26);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 12);
            this.label4.TabIndex = 43;
            this.label4.Text = "12306网站登录名：";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(120, 22);
            this.txtUserName.Margin = new System.Windows.Forms.Padding(2);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(132, 21);
            this.txtUserName.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(256, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 45;
            this.label1.Text = "密码：";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(299, 22);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(2);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(94, 21);
            this.txtPassword.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(396, 26);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 47;
            this.label2.Text = "验证码：";
            // 
            // txtVerificationCode
            // 
            this.txtVerificationCode.Location = new System.Drawing.Point(452, 22);
            this.txtVerificationCode.Margin = new System.Windows.Forms.Padding(2);
            this.txtVerificationCode.MaxLength = 4;
            this.txtVerificationCode.Name = "txtVerificationCode";
            this.txtVerificationCode.Size = new System.Drawing.Size(38, 21);
            this.txtVerificationCode.TabIndex = 2;
            // 
            // gobLoginInfo
            // 
            this.gobLoginInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gobLoginInfo.Controls.Add(this.btnLogin);
            this.gobLoginInfo.Controls.Add(this.label4);
            this.gobLoginInfo.Controls.Add(this.txtVerificationCode);
            this.gobLoginInfo.Controls.Add(this.picValidImg);
            this.gobLoginInfo.Controls.Add(this.label2);
            this.gobLoginInfo.Controls.Add(this.txtUserName);
            this.gobLoginInfo.Controls.Add(this.txtPassword);
            this.gobLoginInfo.Controls.Add(this.label1);
            this.gobLoginInfo.Location = new System.Drawing.Point(9, 10);
            this.gobLoginInfo.Margin = new System.Windows.Forms.Padding(2);
            this.gobLoginInfo.Name = "gobLoginInfo";
            this.gobLoginInfo.Padding = new System.Windows.Forms.Padding(2);
            this.gobLoginInfo.Size = new System.Drawing.Size(784, 55);
            this.gobLoginInfo.TabIndex = 0;
            this.gobLoginInfo.TabStop = false;
            this.gobLoginInfo.Text = "1.登录";
            // 
            // btnLogin
            // 
            this.btnLogin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogin.Location = new System.Drawing.Point(724, 16);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(2);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(56, 34);
            this.btnLogin.TabIndex = 3;
            this.btnLogin.Text = "登录";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // gobSearch
            // 
            this.gobSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gobSearch.Controls.Add(this.pnlTrainType);
            this.gobSearch.Controls.Add(this.radioButton3);
            this.gobSearch.Controls.Add(this.radioButton2);
            this.gobSearch.Controls.Add(this.radioButton1);
            this.gobSearch.Controls.Add(this.checkBox14);
            this.gobSearch.Controls.Add(this.label5);
            this.gobSearch.Controls.Add(this.cboStartTime);
            this.gobSearch.Controls.Add(this.btnSearch);
            this.gobSearch.Controls.Add(this.cboToStation);
            this.gobSearch.Controls.Add(this.dateStartDate);
            this.gobSearch.Controls.Add(this.cboFromStation);
            this.gobSearch.Controls.Add(this.label3);
            this.gobSearch.Location = new System.Drawing.Point(9, 69);
            this.gobSearch.Margin = new System.Windows.Forms.Padding(2);
            this.gobSearch.Name = "gobSearch";
            this.gobSearch.Padding = new System.Windows.Forms.Padding(2);
            this.gobSearch.Size = new System.Drawing.Size(784, 102);
            this.gobSearch.TabIndex = 1;
            this.gobSearch.TabStop = false;
            this.gobSearch.Text = "2.选择车次";
            // 
            // pnlTrainType
            // 
            this.pnlTrainType.Controls.Add(this.checkBox13);
            this.pnlTrainType.Controls.Add(this.checkBox18);
            this.pnlTrainType.Controls.Add(this.checkBox17);
            this.pnlTrainType.Controls.Add(this.checkBox16);
            this.pnlTrainType.Controls.Add(this.checkBox15);
            this.pnlTrainType.Controls.Add(this.checkBox12);
            this.pnlTrainType.Location = new System.Drawing.Point(72, 57);
            this.pnlTrainType.Margin = new System.Windows.Forms.Padding(2);
            this.pnlTrainType.Name = "pnlTrainType";
            this.pnlTrainType.Size = new System.Drawing.Size(328, 30);
            this.pnlTrainType.TabIndex = 5;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Checked = true;
            this.checkBox13.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox13.Location = new System.Drawing.Point(262, 4);
            this.checkBox13.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(48, 16);
            this.checkBox13.TabIndex = 5;
            this.checkBox13.Tag = "QT";
            this.checkBox13.Text = "其它";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Checked = true;
            this.checkBox18.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox18.Location = new System.Drawing.Point(100, 4);
            this.checkBox18.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(54, 16);
            this.checkBox18.TabIndex = 2;
            this.checkBox18.Tag = "Z";
            this.checkBox18.Text = "Z字头";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Checked = true;
            this.checkBox17.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox17.Location = new System.Drawing.Point(52, 4);
            this.checkBox17.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(48, 16);
            this.checkBox17.TabIndex = 1;
            this.checkBox17.Tag = "D";
            this.checkBox17.Text = "动车";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Checked = true;
            this.checkBox16.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox16.Location = new System.Drawing.Point(154, 4);
            this.checkBox16.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(54, 16);
            this.checkBox16.TabIndex = 3;
            this.checkBox16.Tag = "T";
            this.checkBox16.Text = "T字头";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Checked = true;
            this.checkBox15.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox15.Location = new System.Drawing.Point(208, 4);
            this.checkBox15.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(54, 16);
            this.checkBox15.TabIndex = 4;
            this.checkBox15.Tag = "K";
            this.checkBox15.Text = "K字头";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Checked = true;
            this.checkBox12.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox12.Location = new System.Drawing.Point(4, 4);
            this.checkBox12.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(48, 16);
            this.checkBox12.TabIndex = 0;
            this.checkBox12.Tag = "QB";
            this.checkBox12.Text = "全部";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(658, 66);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(47, 16);
            this.radioButton3.TabIndex = 18;
            this.radioButton3.Tag = "SF";
            this.radioButton3.Text = "始发";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(658, 82);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(47, 16);
            this.radioButton2.TabIndex = 19;
            this.radioButton2.Tag = "GL";
            this.radioButton2.Text = "过路";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(658, 50);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(47, 16);
            this.radioButton1.TabIndex = 17;
            this.radioButton1.TabStop = true;
            this.radioButton1.Tag = "QB";
            this.radioButton1.Text = "全部";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(334, 61);
            this.checkBox14.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(48, 16);
            this.checkBox14.TabIndex = 68;
            this.checkBox14.Text = "其它";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 62);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 53;
            this.label5.Text = "火车类型：";
            // 
            // cboStartTime
            // 
            this.cboStartTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboStartTime.ForeColor = System.Drawing.Color.Green;
            this.cboStartTime.FormattingEnabled = true;
            this.cboStartTime.Items.AddRange(new object[] {
            "00:00--24:00",
            "00:00--06:00",
            "06:00--12:00",
            "12:00--18:00",
            "18:00--24:00"});
            this.cboStartTime.Location = new System.Drawing.Point(362, 21);
            this.cboStartTime.Margin = new System.Windows.Forms.Padding(2);
            this.cboStartTime.Name = "cboStartTime";
            this.cboStartTime.Size = new System.Drawing.Size(100, 20);
            this.cboStartTime.TabIndex = 4;
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.Location = new System.Drawing.Point(724, 64);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(56, 34);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.Text = "查询";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // cboToStation
            // 
            this.cboToStation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboToStation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboToStation.ForeColor = System.Drawing.Color.Green;
            this.cboToStation.FormattingEnabled = true;
            this.cboToStation.Location = new System.Drawing.Point(262, 20);
            this.cboToStation.Margin = new System.Windows.Forms.Padding(2);
            this.cboToStation.Name = "cboToStation";
            this.cboToStation.Size = new System.Drawing.Size(85, 20);
            this.cboToStation.TabIndex = 3;
            this.cboToStation.Text = "正在加载...";
            // 
            // dateStartDate
            // 
            this.dateStartDate.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dateStartDate.Location = new System.Drawing.Point(14, 19);
            this.dateStartDate.Margin = new System.Windows.Forms.Padding(2);
            this.dateStartDate.Name = "dateStartDate";
            this.dateStartDate.Size = new System.Drawing.Size(115, 21);
            this.dateStartDate.TabIndex = 1;
            // 
            // cboFromStation
            // 
            this.cboFromStation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboFromStation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboFromStation.ForeColor = System.Drawing.Color.Green;
            this.cboFromStation.FormattingEnabled = true;
            this.cboFromStation.Location = new System.Drawing.Point(149, 19);
            this.cboFromStation.Margin = new System.Windows.Forms.Padding(2);
            this.cboFromStation.Name = "cboFromStation";
            this.cboFromStation.Size = new System.Drawing.Size(85, 20);
            this.cboFromStation.TabIndex = 2;
            this.cboFromStation.Text = "正在加载...";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(129, 24);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(423, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "从              到              ，               上车的车票。";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.dgvTiketInfo);
            this.panel1.Location = new System.Drawing.Point(9, 341);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(998, 379);
            this.panel1.TabIndex = 52;
            // 
            // dgvTiketInfo
            // 
            this.dgvTiketInfo.AllowUserToAddRows = false;
            this.dgvTiketInfo.AllowUserToDeleteRows = false;
            this.dgvTiketInfo.AllowUserToOrderColumns = true;
            this.dgvTiketInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTiketInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTiketInfo.Location = new System.Drawing.Point(0, 0);
            this.dgvTiketInfo.Name = "dgvTiketInfo";
            this.dgvTiketInfo.RowTemplate.Height = 23;
            this.dgvTiketInfo.Size = new System.Drawing.Size(998, 379);
            this.dgvTiketInfo.TabIndex = 0;
            this.dgvTiketInfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTiketInfo_CellContentClick);
            this.dgvTiketInfo.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTiketInfo_CellDoubleClick);
            this.dgvTiketInfo.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTiketInfo_CellValueChanged);
            // 
            // gobRefresh
            // 
            this.gobRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gobRefresh.Controls.Add(this.lblSeate);
            this.gobRefresh.Controls.Add(this.gobPassenger);
            this.gobRefresh.Controls.Add(this.gobSeatType);
            this.gobRefresh.Controls.Add(this.label12);
            this.gobRefresh.Controls.Add(this.numJiange);
            this.gobRefresh.Controls.Add(this.label11);
            this.gobRefresh.Controls.Add(this.chbMusic);
            this.gobRefresh.Controls.Add(this.chbAutoOrder);
            this.gobRefresh.Controls.Add(this.btnRefresh);
            this.gobRefresh.Controls.Add(this.gobSelectedTicket);
            this.gobRefresh.Location = new System.Drawing.Point(9, 175);
            this.gobRefresh.Margin = new System.Windows.Forms.Padding(2);
            this.gobRefresh.Name = "gobRefresh";
            this.gobRefresh.Padding = new System.Windows.Forms.Padding(2);
            this.gobRefresh.Size = new System.Drawing.Size(784, 161);
            this.gobRefresh.TabIndex = 2;
            this.gobRefresh.TabStop = false;
            this.gobRefresh.Text = "3.刷票";
            // 
            // lblSeate
            // 
            this.lblSeate.AutoSize = true;
            this.lblSeate.ForeColor = System.Drawing.Color.Red;
            this.lblSeate.Location = new System.Drawing.Point(239, 140);
            this.lblSeate.Name = "lblSeate";
            this.lblSeate.Size = new System.Drawing.Size(77, 12);
            this.lblSeate.TabIndex = 64;
            this.lblSeate.Text = "座席优先级：";
            // 
            // gobPassenger
            // 
            this.gobPassenger.Controls.Add(this.chbListPassenger);
            this.gobPassenger.Location = new System.Drawing.Point(392, 13);
            this.gobPassenger.Name = "gobPassenger";
            this.gobPassenger.Size = new System.Drawing.Size(188, 119);
            this.gobPassenger.TabIndex = 63;
            this.gobPassenger.TabStop = false;
            this.gobPassenger.Text = "选择乘客(注意右侧信息提示)";
            // 
            // chbListPassenger
            // 
            this.chbListPassenger.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.chbListPassenger.FormattingEnabled = true;
            this.chbListPassenger.Location = new System.Drawing.Point(4, 19);
            this.chbListPassenger.Name = "chbListPassenger";
            this.chbListPassenger.Size = new System.Drawing.Size(179, 84);
            this.chbListPassenger.TabIndex = 0;
            // 
            // gobSeatType
            // 
            this.gobSeatType.Controls.Add(this.chbListSeatType);
            this.gobSeatType.Location = new System.Drawing.Point(243, 13);
            this.gobSeatType.Name = "gobSeatType";
            this.gobSeatType.Size = new System.Drawing.Size(143, 119);
            this.gobSeatType.TabIndex = 62;
            this.gobSeatType.TabStop = false;
            this.gobSeatType.Text = "座位类型";
            // 
            // chbListSeatType
            // 
            this.chbListSeatType.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.chbListSeatType.FormattingEnabled = true;
            this.chbListSeatType.Location = new System.Drawing.Point(4, 19);
            this.chbListSeatType.Name = "chbListSeatType";
            this.chbListSeatType.Size = new System.Drawing.Size(134, 84);
            this.chbListSeatType.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(752, 37);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 12);
            this.label12.TabIndex = 61;
            this.label12.Text = "秒";
            // 
            // numJiange
            // 
            this.numJiange.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.numJiange.Location = new System.Drawing.Point(707, 32);
            this.numJiange.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numJiange.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numJiange.Name = "numJiange";
            this.numJiange.Size = new System.Drawing.Size(42, 21);
            this.numJiange.TabIndex = 60;
            this.numJiange.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(705, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 59;
            this.label11.Text = "刷票间隔：";
            // 
            // chbMusic
            // 
            this.chbMusic.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chbMusic.AutoSize = true;
            this.chbMusic.Location = new System.Drawing.Point(707, 80);
            this.chbMusic.Name = "chbMusic";
            this.chbMusic.Size = new System.Drawing.Size(72, 16);
            this.chbMusic.TabIndex = 58;
            this.chbMusic.Text = "声音提示";
            this.chbMusic.UseVisualStyleBackColor = true;
            // 
            // chbAutoOrder
            // 
            this.chbAutoOrder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chbAutoOrder.AutoSize = true;
            this.chbAutoOrder.Location = new System.Drawing.Point(707, 102);
            this.chbAutoOrder.Name = "chbAutoOrder";
            this.chbAutoOrder.Size = new System.Drawing.Size(72, 16);
            this.chbAutoOrder.TabIndex = 56;
            this.chbAutoOrder.Text = "自动下单";
            this.chbAutoOrder.UseVisualStyleBackColor = true;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefresh.Location = new System.Drawing.Point(724, 123);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(2);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(56, 34);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "刷票";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // gobSelectedTicket
            // 
            this.gobSelectedTicket.Controls.Add(this.lsbSelectedTicket);
            this.gobSelectedTicket.Location = new System.Drawing.Point(11, 13);
            this.gobSelectedTicket.Margin = new System.Windows.Forms.Padding(2);
            this.gobSelectedTicket.Name = "gobSelectedTicket";
            this.gobSelectedTicket.Padding = new System.Windows.Forms.Padding(2);
            this.gobSelectedTicket.Size = new System.Drawing.Size(227, 144);
            this.gobSelectedTicket.TabIndex = 0;
            this.gobSelectedTicket.TabStop = false;
            this.gobSelectedTicket.Text = "已选车次";
            // 
            // lsbSelectedTicket
            // 
            this.lsbSelectedTicket.FormattingEnabled = true;
            this.lsbSelectedTicket.ItemHeight = 12;
            this.lsbSelectedTicket.Location = new System.Drawing.Point(4, 15);
            this.lsbSelectedTicket.Margin = new System.Windows.Forms.Padding(2);
            this.lsbSelectedTicket.Name = "lsbSelectedTicket";
            this.lsbSelectedTicket.Size = new System.Drawing.Size(219, 124);
            this.lsbSelectedTicket.TabIndex = 0;
            this.lsbSelectedTicket.DoubleClick += new System.EventHandler(this.lsbSelectedTicket_DoubleClick);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 10F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Brown;
            this.label8.Location = new System.Drawing.Point(810, 81);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(202, 42);
            this.label8.TabIndex = 53;
            this.label8.Text = "准备工作：登录后一定要预先\r\n点击上方图标进入12306网站\r\n预先编辑好乘车人信息。";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(9, 723);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(149, 12);
            this.label9.TabIndex = 54;
            this.label9.Text = "注：双击车次可直接订票。";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(103)))), ((int)(((byte)(175)))));
            this.label10.Location = new System.Drawing.Point(552, 724);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(455, 12);
            this.label10.TabIndex = 55;
            this.label10.Text = "有：票源充足        无：票已售完        *：未到起售时间        --：无此席别";
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1018, 743);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.picLoginIE);
            this.Controls.Add(this.gobRefresh);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gobSearch);
            this.Controls.Add(this.gobLoginInfo);
            this.Controls.Add(this.lstMsg);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(900, 616);
            this.Name = "Form_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "开源软件";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Main_FormClosing);
            this.Load += new System.EventHandler(this.frmTicketsHelper_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picValidImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLoginIE)).EndInit();
            this.gobLoginInfo.ResumeLayout(false);
            this.gobLoginInfo.PerformLayout();
            this.gobSearch.ResumeLayout(false);
            this.gobSearch.PerformLayout();
            this.pnlTrainType.ResumeLayout(false);
            this.pnlTrainType.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTiketInfo)).EndInit();
            this.gobRefresh.ResumeLayout(false);
            this.gobRefresh.PerformLayout();
            this.gobPassenger.ResumeLayout(false);
            this.gobSeatType.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numJiange)).EndInit();
            this.gobSelectedTicket.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ListBox lstMsg;
        private System.Windows.Forms.PictureBox picValidImg;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtVerificationCode;
        private System.Windows.Forms.GroupBox gobLoginInfo;
        private System.Windows.Forms.GroupBox gobSearch;
        private System.Windows.Forms.ComboBox cboToStation;
        private System.Windows.Forms.DateTimePicker dateStartDate;
        private System.Windows.Forms.ComboBox cboFromStation;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ComboBox cboStartTime;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.GroupBox gobRefresh;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.GroupBox gobSelectedTicket;
        private System.Windows.Forms.ListBox lsbSelectedTicket;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.Panel pnlTrainType;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox chbAutoOrder;
        private System.Windows.Forms.PictureBox picLoginIE;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dgvTiketInfo;
        private System.Windows.Forms.CheckBox chbMusic;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown numJiange;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox gobSeatType;
        private System.Windows.Forms.CheckedListBox chbListSeatType;
        private System.Windows.Forms.Label lblSeate;
        private System.Windows.Forms.GroupBox gobPassenger;
        private System.Windows.Forms.CheckedListBox chbListPassenger;
    }
}