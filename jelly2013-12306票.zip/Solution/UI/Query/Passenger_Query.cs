﻿using System;
using System.Collections.Generic;
using System.Text;
using Jelly2013.Entity;

namespace Jelly2013.Query
{
    public class Passenger_Query
    {
        public static List<Passenger> List = new List<Passenger>();
        public static void GetList(object obj)
        {
            List.Clear();
            string url = "https://dynamic.12306.cn/otsweb/order/confirmPassengerAction.do?method=getpassengerJson";
            string webResult = string.Empty;
            try
            {
                webResult = CommUitl.getString(url, null, "https://dynamic.12306.cn/otsweb/order/querySingleAction.do?method=init");
            }
            catch (Exception)
            {
                GetList(null);
            }
            if (webResult.IndexOf("passengerJson") > -1)
            {
                webResult = webResult.Substring(webResult.IndexOf("passengerJson") + 15);
                webResult = webResult.Remove(webResult.Length - 1);
                //webResult = CommUitl.ReplaceHTMLAttributes(webResult);
                webResult = webResult.Replace("[", string.Empty);
                webResult = webResult.Replace("]", string.Empty);
                string[] strPasserngers = webResult.Split(new string[] { "},{" }, StringSplitOptions.RemoveEmptyEntries);
                Passenger passenger;
                string[] passengerProperties;
                string strPassernger1;
                foreach (var strPassernger in strPasserngers)
                {
                    passenger = new Passenger();
                    strPassernger1 = strPassernger.Replace("\"", string.Empty);
                    passengerProperties = strPassernger1.Split(',');
                    passenger.MobileNo = passengerProperties[2].Split(':')[1];
                    passenger.CardNo = passengerProperties[7].Split(':')[1];
                    passenger.IDCardType = passengerProperties[8].Split(':')[1];
                    passenger.Name = passengerProperties[10].Split(':')[1];
                    List.Add(passenger);
                }
            }
        }
    }
}
