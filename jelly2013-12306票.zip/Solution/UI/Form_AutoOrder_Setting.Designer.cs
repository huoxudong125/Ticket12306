﻿namespace Jelly2013
{
    partial class Form_AutoOrder_Setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_AutoOrder_Setting));
            this.gobPassenger = new System.Windows.Forms.GroupBox();
            this.pnlPassenger = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.gobPassenger.SuspendLayout();
            this.SuspendLayout();
            // 
            // gobPassenger
            // 
            this.gobPassenger.Controls.Add(this.pnlPassenger);
            this.gobPassenger.Location = new System.Drawing.Point(10, 10);
            this.gobPassenger.Name = "gobPassenger";
            this.gobPassenger.Size = new System.Drawing.Size(650, 200);
            this.gobPassenger.TabIndex = 2;
            this.gobPassenger.TabStop = false;
            this.gobPassenger.Text = "请勾选自动购票的乘客";
            // 
            // pnlPassenger
            // 
            this.pnlPassenger.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPassenger.Location = new System.Drawing.Point(3, 17);
            this.pnlPassenger.Name = "pnlPassenger";
            this.pnlPassenger.Size = new System.Drawing.Size(644, 180);
            this.pnlPassenger.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(601, 224);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(56, 18);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // Form_AutoOrder_Setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 270);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.gobPassenger);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(684, 297);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(684, 297);
            this.Name = "Form_AutoOrder_Setting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "配置自动下单功能";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form_AutoOrder_Setting_Load);
            this.gobPassenger.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gobPassenger;
        private System.Windows.Forms.Panel pnlPassenger;
        private System.Windows.Forms.Button btnSave;
    }
}