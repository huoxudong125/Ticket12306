﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using Jelly2013.Entity;

namespace Jelly2013
{
    public class CommData
    {
        /// <summary>
        /// cookie容器
        /// </summary>
        public static CookieContainer cookieContainer=new CookieContainer();
        /// <summary>
        /// cookie集合
        /// </summary>
        public static CookieCollection cookieCollection=new CookieCollection();

        private static int seatTypeCount=-1;
        public static int SeatTypeCount
        {
            get
            {
                if (seatTypeCount == -1)
                {
                    seatTypeCount = CommUitl.GetEnumCount(typeof(SeatType));
                }
                return seatTypeCount;
            }
        }

        private static Dictionary<SeatType, string> seatTypeNo;
        /// <summary>
        /// 座位类型编号
        /// </summary>
        public static Dictionary<SeatType, string> SeatTypeNo
        {
            get
            {
                if (seatTypeNo == null)
                {
                    seatTypeNo = new Dictionary<SeatType, string>();
                    seatTypeNo.Add(SeatType.无座, "-1");
                    seatTypeNo.Add(SeatType.硬座, "1");
                    seatTypeNo.Add(SeatType.软座, "2");
                    seatTypeNo.Add(SeatType.硬卧, "3");
                    seatTypeNo.Add(SeatType.软卧, "4");
                    seatTypeNo.Add(SeatType.高级软卧, "6");
                    seatTypeNo.Add(SeatType.商务座, "9");
                    seatTypeNo.Add(SeatType.一等座, "M");
                    seatTypeNo.Add(SeatType.二等座, "O");
                    seatTypeNo.Add(SeatType.特等座, "P");
                }
                return seatTypeNo;
            }
        }
        private static Dictionary<SeatType, string> seatTypeName;
        /// <summary>
        /// 座位类型名称
        /// </summary>
        public static Dictionary<SeatType, string> SeatTypeName
        {
            get
            {
                if (seatTypeName == null)
                {
                    seatTypeName = new Dictionary<SeatType, string>();
                    seatTypeName.Add(SeatType.无座, "无座");
                    seatTypeName.Add(SeatType.硬座, "硬座");
                    seatTypeName.Add(SeatType.软座, "软座");
                    seatTypeName.Add(SeatType.硬卧, "硬卧");
                    seatTypeName.Add(SeatType.软卧, "软卧");
                    seatTypeName.Add(SeatType.高级软卧, "高级软卧");
                    seatTypeName.Add(SeatType.商务座, "商务座");
                    seatTypeName.Add(SeatType.一等座, "一等座");
                    seatTypeName.Add(SeatType.二等座, "二等座");
                    seatTypeName.Add(SeatType.特等座, "特等座");
                }
                return seatTypeName;
            }
        }
    }
}
