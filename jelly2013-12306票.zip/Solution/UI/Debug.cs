﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Jelly2013
{
    static class Debug
    {
        public static void Log(string msg)
        {
            string path = @"C:\Debug.log";
            File.AppendAllText(path, "【" + DateTime.Now.ToShortTimeString() + "】\t" + msg + Environment.NewLine);
        }
    }
}
