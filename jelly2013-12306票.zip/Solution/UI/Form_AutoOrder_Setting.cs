﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Jelly2013.Query;
using Jelly2013.Entity;

namespace Jelly2013
{
    public partial class Form_AutoOrder_Setting : Form
    {
        public static List<Passenger> _AutoOrderPassengers = new List<Passenger>();
        public Form_AutoOrder_Setting()
        {
            InitializeComponent();
        }

        private void Form_AutoOrder_Setting_Load(object sender, EventArgs e)
        {
            initPassenger();
        }
        private void initPassenger()
        {
            Passenger_Query.GetList(null);
            List<Passenger> list = Passenger_Query.List;
            pnlPassenger.Controls.Clear();
            Point p = new Point(20, 50);
            for (int i = 0; i < list.Count; i++)
            {
                Passenger item = list[i];
                CheckBox chkbox = new CheckBox();
                chkbox.Name = "chk" + item.CardNo;
                chkbox.Text = item.Name;
                chkbox.Tag = item;
                chkbox.AutoSize = true;
                foreach (Passenger pass in _AutoOrderPassengers)
                {
                    if (pass.CardNo == item.CardNo)
                    {
                        chkbox.Checked = true;
                    }
                }
                chkbox.CheckedChanged += new EventHandler(chkbox_CheckedChanged);
                p.X = i % 8 * 80 + 5;
                if (i % 8 == 0)
                {
                    p.X = 25;
                    p.Y = i / 5 * 25;
                }
                chkbox.Location = p;
                pnlPassenger.Controls.Add(chkbox);
            }
        }
        void chkbox_CheckedChanged(object sender, EventArgs e)
        {
            if (_AutoOrderPassengers.Count > 4)
            {
                MessageBox.Show("一次订票最多添加【5】名乘客！");
                return;
            }
            CheckBox chkbox = sender as CheckBox;
            Passenger passenger = chkbox.Tag as Passenger;
            if (chkbox.Checked == true)
            {
                _AutoOrderPassengers.Add(passenger);
            }
            else
            {
                _AutoOrderPassengers.Remove(passenger);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
