﻿namespace Jelly2013
{
    partial class Form_Order_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Order_Add));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvOrder = new System.Windows.Forms.DataGridView();
            this.gobPassenger = new System.Windows.Forms.GroupBox();
            this.pnlPassenger = new System.Windows.Forms.Panel();
            this.lblTrainInfo = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblSeateInfo = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtVerificationCode = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.picValidImg = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrder)).BeginInit();
            this.gobPassenger.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picValidImg)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvOrder);
            this.panel1.Location = new System.Drawing.Point(8, 20);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(638, 149);
            this.panel1.TabIndex = 0;
            // 
            // dgvOrder
            // 
            this.dgvOrder.AllowUserToAddRows = false;
            this.dgvOrder.AllowUserToDeleteRows = false;
            this.dgvOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvOrder.Location = new System.Drawing.Point(0, 0);
            this.dgvOrder.Name = "dgvOrder";
            this.dgvOrder.RowTemplate.Height = 23;
            this.dgvOrder.Size = new System.Drawing.Size(638, 149);
            this.dgvOrder.TabIndex = 0;
            this.dgvOrder.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvOrder_DataError);
            // 
            // gobPassenger
            // 
            this.gobPassenger.Controls.Add(this.pnlPassenger);
            this.gobPassenger.Location = new System.Drawing.Point(10, 78);
            this.gobPassenger.Name = "gobPassenger";
            this.gobPassenger.Size = new System.Drawing.Size(650, 85);
            this.gobPassenger.TabIndex = 1;
            this.gobPassenger.TabStop = false;
            this.gobPassenger.Text = "我的常用联系人";
            // 
            // pnlPassenger
            // 
            this.pnlPassenger.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPassenger.Location = new System.Drawing.Point(3, 17);
            this.pnlPassenger.Name = "pnlPassenger";
            this.pnlPassenger.Size = new System.Drawing.Size(644, 65);
            this.pnlPassenger.TabIndex = 0;
            // 
            // lblTrainInfo
            // 
            this.lblTrainInfo.AutoSize = true;
            this.lblTrainInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(114)))), ((int)(((byte)(186)))));
            this.lblTrainInfo.Location = new System.Drawing.Point(5, 20);
            this.lblTrainInfo.Name = "lblTrainInfo";
            this.lblTrainInfo.Size = new System.Drawing.Size(569, 12);
            this.lblTrainInfo.TabIndex = 2;
            this.lblTrainInfo.Text = "2013年01月25日\tK819次        北京西（09:08 开 ）        重庆北（11:43到 ）        历时（26:35）";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblSeateInfo);
            this.groupBox1.Controls.Add(this.lblTrainInfo);
            this.groupBox1.Location = new System.Drawing.Point(9, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(651, 62);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "列车信息";
            // 
            // lblSeateInfo
            // 
            this.lblSeateInfo.AutoSize = true;
            this.lblSeateInfo.Location = new System.Drawing.Point(5, 40);
            this.lblSeateInfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSeateInfo.Name = "lblSeateInfo";
            this.lblSeateInfo.Size = new System.Drawing.Size(581, 12);
            this.lblSeateInfo.TabIndex = 0;
            this.lblSeateInfo.Text = "硬卧(393.00元)无票        硬座(224.00元)有票        软卧(625.00元)无票        无座(224.00元)有票";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Location = new System.Drawing.Point(9, 168);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(651, 174);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "乘车人信息";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 346);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "验证码：";
            // 
            // txtVerificationCode
            // 
            this.txtVerificationCode.Location = new System.Drawing.Point(70, 345);
            this.txtVerificationCode.Margin = new System.Windows.Forms.Padding(2);
            this.txtVerificationCode.MaxLength = 4;
            this.txtVerificationCode.Name = "txtVerificationCode";
            this.txtVerificationCode.Size = new System.Drawing.Size(62, 21);
            this.txtVerificationCode.TabIndex = 6;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(500, 347);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(2);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(79, 36);
            this.btnSubmit.TabIndex = 7;
            this.btnSubmit.Text = "提交订单";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(583, 346);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(73, 36);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "取消";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // picValidImg
            // 
            this.picValidImg.Location = new System.Drawing.Point(134, 346);
            this.picValidImg.Name = "picValidImg";
            this.picValidImg.Size = new System.Drawing.Size(78, 26);
            this.picValidImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picValidImg.TabIndex = 39;
            this.picValidImg.TabStop = false;
            // 
            // Form_Order_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 414);
            this.Controls.Add(this.picValidImg);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtVerificationCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gobPassenger);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form_Order_Add";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "争分夺秒地下单";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form_Order_Add_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrder)).EndInit();
            this.gobPassenger.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picValidImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gobPassenger;
        private System.Windows.Forms.Label lblTrainInfo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblSeateInfo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtVerificationCode;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.PictureBox picValidImg;
        private System.Windows.Forms.Panel pnlPassenger;
        private System.Windows.Forms.DataGridView dgvOrder;
    }
}