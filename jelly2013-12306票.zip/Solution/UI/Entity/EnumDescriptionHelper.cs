﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jelly2013.Entity
{
    /// <summary>
    /// 枚举描述
    /// </summary>
    public class SeatTypeDescriptionHelper
    {
        private static Dictionary<SeatType, string> description;
        public static Dictionary<SeatType, string> Description
        {
            get
            {
                if (description == null)
                {
                    description = new Dictionary<SeatType, string>();
                    description.Add(SeatType.商务座, "商务座");
                    description.Add(SeatType.特等座, "特等座");
                    description.Add(SeatType.一等座, "一等座");
                    description.Add(SeatType.二等座, "二等座");
                    description.Add(SeatType.高级软卧, "高级软卧");
                    description.Add(SeatType.软卧, "软卧");
                    description.Add(SeatType.硬卧, "硬卧");
                    description.Add(SeatType.软座, "软座");
                    description.Add(SeatType.硬座, "硬座");
                    description.Add(SeatType.无座, "无座");
                    description.Add(SeatType.其它, "其他");
                }
                return description;
            }
        }
    }
}
