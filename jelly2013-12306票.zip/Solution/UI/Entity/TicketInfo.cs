﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jelly2013.Entity
{
    /// <summary>
    /// 列车车票数量信息
    /// </summary>
    public class TicketInfo
    {
        /// <summary>
        /// 选择
        /// </summary>
        public bool Selected { get; set; }    
        /// <summary>
        /// 编号
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 车次
        /// </summary>
        public string StationTrainCode { get; set; }
        /// <summary>
        /// 发站
        /// </summary>
        public string DepartureStation { get; set; }
        /// <summary>
        /// 开车时间
        /// </summary>
        public string DrivingTime { get; set; }
        /// <summary>
        /// 到站
        /// </summary>
        public string DestinationStation { get; set; }
        /// <summary>
        /// 到达时间
        /// </summary>
        public string ArrivalTime { get; set; }
        /// <summary>
        /// 历时
        /// </summary>
        public string ElapsedTime { get; set; }
        /// <summary>
        /// 座位信息
        /// </summary>
        public Dictionary<SeatType, int> SeetInfos { get; set; }

        #region 各类座位信息
        string businessBlock;
        /// <summary>
        /// 商务
        /// </summary>
        public string 商务座
        {
            get
            {
                return businessBlock;
            }
            set
            {
                if (businessBlock != value)
                {
                    businessBlock = value;
                    UpdateSeatInfo(SeatType.商务座, value);
                }
            }
        }
        string principalSeat;
        /// <summary>
        /// 特等
        /// </summary>
        public string 特等座
        {
            get
            {
                return principalSeat;
            }
            set
            {
                if (principalSeat != value)
                {
                    principalSeat = value;
                    UpdateSeatInfo(SeatType.特等座, value);
                }
            }
        }
        string firstClassSeat;
        /// <summary>
        /// 一等
        /// </summary>
        public string 一等座
        {
            get
            {
                return firstClassSeat;
            }
            set
            {
                if (firstClassSeat != value)
                {
                    firstClassSeat = value;
                    UpdateSeatInfo(SeatType.一等座, value);
                }
            }
        }
        string secondClassSeat;
        /// <summary>
        /// 二等
        /// </summary>
        public string 二等座
        {
            get
            {
                return secondClassSeat;
            }
            set
            {
                if (secondClassSeat != value)
                {
                    secondClassSeat = value;
                    UpdateSeatInfo(SeatType.二等座, value);
                }
            }
        }
        string advancedSoftSleeper;
        /// <summary>
        /// 高级软卧
        /// </summary>
        public string 高级软卧
        {
            get
            {
                return advancedSoftSleeper;
            }
            set
            {
                if (advancedSoftSleeper != value)
                {
                    advancedSoftSleeper = value;
                    UpdateSeatInfo(SeatType.高级软卧, value);
                }
            }
        }
        string softSleeper;
        /// <summary>
        /// 软卧
        /// </summary>
        public string 软卧
        {
            get
            {
                return softSleeper;
            }
            set
            {
                if (softSleeper != value)
                {
                    softSleeper = value;
                    UpdateSeatInfo(SeatType.软卧, value);
                }
            }
        }
        string hardSleeper;
        /// <summary>
        /// 硬卧
        /// </summary>
        public string 硬卧
        {
            get
            {
                return hardSleeper;
            }
            set
            {
                if (hardSleeper != value)
                {
                    hardSleeper = value;
                    UpdateSeatInfo(SeatType.硬卧, value);
                }
            }
        }
        string softSeat;
        /// <summary>
        /// 软座
        /// </summary>
        public string 软座
        {
            get
            {
                return softSeat;
            }
            set
            {
                if (softSeat != value)
                {
                    softSeat = value;
                    UpdateSeatInfo(SeatType.软座, value);
                }
            }
        }
        string hardSeat;
        /// <summary>
        /// 硬座
        /// </summary>
        public string 硬座
        {
            get
            {
                return hardSeat;
            }
            set
            {
                if (hardSeat != value)
                {
                    hardSeat = value;
                    UpdateSeatInfo(SeatType.硬座, value);
                }
            }
        }
        string noSeat;
        /// <summary>
        /// 无座
        /// </summary>
        public string 无座
        {
            get
            {
                return noSeat;
            }
            set
            {
                if (noSeat != value)
                {
                    noSeat = value;
                    UpdateSeatInfo(SeatType.无座, value);
                }
            }
        }
        string other;
        /// <summary>
        /// 其他
        /// </summary>
        public string 其它
        {
            get
            {
                return other;
            }
            set
            {
                if (other != value)
                {
                    other = value;
                    UpdateSeatInfo(SeatType.其它, value);
                }
            }
        }
        #endregion

        private string jsInfoString;
        /// <summary>
        /// 页面中预订按钮点击时JS包含的信息,用于预订车票 
        /// 2013-01-05#T109#14:22#19:33#240000T1090G#BJP#SHH#09:55#北京#上海#01#11#1*****30174*****00001*****00006*****00033*****0000#6920A30E64A35B946D8E807B1C1D428740BC66F832E2FBC6869FA30A#P3')>
        /// </summary>
        public string JsInfoString
        {
            get
            {
                return jsInfoString;
            }
            set
            {
                if (jsInfoString != value)
                {
                    jsInfoString = value;
                    string[] infos = jsInfoString.Split('#');
                    TrainDate = infos[0];
                    TrainNo = infos[1+3];
                    DepartureStationTelCode = infos[1+4];
                    DestinationStationTelCode = infos[1+5];
                    InfoDetail = infos[12];
                    MmStr = infos[13];
                    LocationCode = infos[14];
                    From_station_no = infos[10];
                    To_station_no = infos[11];
                }
            }
        }

        #region 从jsInfo中得到的属性
        public string LocationCode { get; set; }
        public string From_station_no { get; set; }
        public string To_station_no { get; set; }
        /// <summary>
        /// 列车编号
        /// </summary>
        public string TrainNo { get; set; }
        /// <summary>
        /// 列车日期
        /// </summary>
        public string TrainDate { get; set; }
        /// <summary>
        /// 发站编号
        /// </summary>
        public string DepartureStationTelCode { get; set; }
        /// <summary>
        /// 到站编号
        /// </summary>
        public string DestinationStationTelCode { get; set; }
        /// <summary>
        /// ypInfoDetail
        /// </summary>
        public string InfoDetail { get; set; }
        /// <summary>
        /// mmStr
        /// </summary>
        public string MmStr { get; set; }
        #endregion

        /// <summary>
        /// 更新剩余票信息
        /// </summary>
        /// <param name="seatType"></param>
        /// <param name="value"></param>
        private void UpdateSeatInfo(SeatType seatType, string value)
        {
            int seatCount;
            if (Int32.TryParse(value,out seatCount)==false)
            {
                if (value == "有")
                {
                    seatCount = int.MaxValue;
                }
                else
                {
                    seatCount = 0;
                }
            }
            if (SeetInfos == null)
            {
                SeetInfos = new Dictionary<SeatType, int>();
            }
            if (SeetInfos.ContainsKey(seatType) == true)
            {
                if (SeetInfos[seatType] != seatCount)
                {
                    SeetInfos[seatType] = seatCount;
                }
            }
            else
            {
                SeetInfos.Add(seatType, seatCount);
            }
        }
        /// <summary>
        /// 有票
        /// </summary>
        public bool IsAvailable
        {
            get
            {
                bool result=false;
                foreach (KeyValuePair<SeatType,int> item in SeetInfos)
                {
                    if (item.Value > 0)
                    {
                        result= true;
                        break;
                    }
                }
                return result;
            }
        }

        /// <summary>
        /// 有票
        /// </summary>
        /// <param name="seatType"></param>
        /// <returns></returns>
        public bool IsAvailable_Seat(params SeatType[] seatType)
        {
            bool result = false;
            if (seatType == null || seatType.Length == 0)
            {

            }
            else
            {
                foreach (var item in SeetInfos)
                {
                    if (Array.IndexOf(seatType,item.Key)!=-1&&item.Value > 0)
                    {
                        result = true;
                        break;
                    }
                }
            }
            return result;
        }
        public override string ToString()
        {
            return TrainDate + " " + this.StationTrainCode + ":" + this.DepartureStation + ">" + this.DestinationStation;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || obj == DBNull.Value)
            {
                return false;
            }
            TicketInfo t = obj as TicketInfo;
            return TrainDate == t.TrainDate &&
                this.TrainNo == t.TrainNo;
        }
    }
}
