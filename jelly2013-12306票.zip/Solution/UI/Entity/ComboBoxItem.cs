﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jelly2013.Entity
{
    public class ComboBoxItem
    {
        public ComboBoxItem(object _value, string _text)
        {
            Value = _value;
            Text = _text;
        }
        public object Value { get; set; }
        public string Text { get; set; }
        public override string ToString()
        {
            return Text;
        }
    }
}
