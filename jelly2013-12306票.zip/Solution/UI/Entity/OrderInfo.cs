﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jelly2013.Entity
{
    public class OrderInfo
    {
        public string Left_ticket { get; set; }
        public string Token { get; set; }
        public string TrainDate{get;set;}
        public TicketInfo TicketInfo{get;set;}
        List<Passenger> passengers;
        public List<Passenger> Passengers
        {
            get
            {
                if (passengers == null)
                {
                    passengers = new List<Passenger>();
                }
                return passengers;
            }
            set
            {
                passengers = value;
            }
        }
    }
}
