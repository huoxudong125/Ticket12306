﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jelly2013.Entity
{
    /// <summary>
    /// 座位类型
    /// </summary>
    public enum SeatType
    {
        /// <summary>
        /// 商务
        /// </summary>
        商务座,
        /// <summary>
        /// 特等
        /// </summary>
        特等座,
        /// <summary>
        /// 一等
        /// </summary>
        一等座,
        /// <summary>
        /// 二等
        /// </summary>
        二等座,
        /// <summary>
        /// 高级软卧
        /// </summary>
        高级软卧,
        /// <summary>
        /// 软卧
        /// </summary>
        软卧,
        /// <summary>
        /// 硬卧
        /// </summary>
        硬卧,
        /// <summary>
        /// 软座
        /// </summary>
        软座,
        /// <summary>
        /// 硬座
        /// </summary>
        硬座,
        /// <summary>
        /// 无座
        /// </summary>
        无座,
        /// <summary>
        /// 其它
        /// </summary>
        其它
    }

    /// <summary>
    /// 证件类型
    /// </summary>
    public enum CardType
    {
        /// <summary>
        /// 二代身份证
        /// </summary>
        SecondgenerationIDCards,
        /// <summary>
        /// 一代身份证
        /// </summary>
        FirstgenerationIDCards,
        /// <summary>
        /// 港澳通行证
        /// </summary>
        HMEntryPermit,
        /// <summary>
        /// 台湾通行证
        /// </summary>
        TWEntryPermit,
        /// <summary>
        /// 护照
        /// </summary>
        Passport,
    }
}
